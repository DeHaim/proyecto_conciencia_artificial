#!/bin/bash

pip install torch numpy pandas scikit-learn nltk spacy matplotlib seaborn opencv-python